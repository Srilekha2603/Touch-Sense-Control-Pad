/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2026 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include<stdio.h>
#include<string.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
UART_HandleTypeDef huart1;

osThreadId defaultTaskHandle;
osTimerId myTimer01Handle;
osMutexId myMutex01Handle;
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);
//void StartDefaultTask(void const * argument);
//void Callback01(void const * argument);

/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
EventGroupHandle_t EventGroupHandle;
SemaphoreHandle_t mutexHandle;
TaskHandle_t Task1Handle;
TaskHandle_t Task2Handle;
TaskHandle_t Task3Handle;
TaskHandle_t EmerTaskHandle;
TaskHandle_t ControlHandle, UARTHandle;
TimerHandle_t TimerHandle;

#define Task1_sw GPIO_PIN_10
#define Task2_sw GPIO_PIN_11
#define Task3_sw GPIO_PIN_12
#define Emer_sw  GPIO_PIN_14

#define EMER_TASK_BIT 0x01
#define TASK1_BIT 0x02
#define TASK2_BIT 0x04
#define TASK3_BIT 0x08

void Task1(void *args);
void Task2(void *args);
void Task3(void *args);
void Emer_Task(void *args);
void UART_Task(void*args);
void TimerTask(void *args);

int _write(int file, char*ptr, int len)
{
	HAL_UART_Transmit(&huart1, (uint8_t *)ptr, (uint16_t)len,portMAX_DELAY);
	return len;
}

void Toggle_LED(uint16_t pin) {
	xSemaphoreTake(mutexHandle, portMAX_DELAY);
	HAL_GPIO_TogglePin(GPIOG, pin);
	xSemaphoreGive(mutexHandle);
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {

	BaseType_t xHigherPriorityTaskWoken = pdFALSE;
	xTimerStartFromISR(TimerHandle,xHigherPriorityTaskWoken);

//	if (GPIO_Pin == GPIO_PIN_0) {
//		xEventGroupSetBitsFromISR(EventGroupHandle, EMER_TASK_BIT,
//				&xHigherPriorityTaskWoken);
//	} else if (GPIO_Pin == GPIO_PIN_1) {
//		xEventGroupSetBitsFromISR(EventGroupHandle, TASK1_BIT,
//				&xHigherPriorityTaskWoken);
//	} else if (GPIO_Pin == GPIO_PIN_2) {
//		xEventGroupSetBitsFromISR(EventGroupHandle, TASK2_BIT,
//				&xHigherPriorityTaskWoken);
//	} else if (GPIO_Pin == GPIO_PIN_3) {
//		xEventGroupSetBitsFromISR(EventGroupHandle, TASK3_BIT,
//				&xHigherPriorityTaskWoken);
//	}
	portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}

void controller_Task(void *args) {
	uint8_t bit;
	for (;;) {
		bit = xEventGroupWaitBits(EventGroupHandle,
				EMER_TASK_BIT | TASK1_BIT | TASK2_BIT | TASK3_BIT, pdTRUE,
				pdFALSE, portMAX_DELAY);
		switch (bit) {
		case 0x01:
			vTaskResume(EmerTaskHandle);
			vTaskSuspend(Task1Handle);
			vTaskSuspend(Task2Handle);
			vTaskSuspend(Task3Handle);
			break;
		case 0x02:
			vTaskResume(Task1Handle);
			vTaskSuspend(EmerTaskHandle);
			vTaskSuspend(Task2Handle);
			vTaskSuspend(Task3Handle);
			break;
		case 0x04:
			vTaskResume(Task2Handle);
			vTaskSuspend(Task1Handle);
			vTaskSuspend(EmerTaskHandle);
			vTaskSuspend(Task3Handle);
			break;
		case 0x08:
			vTaskResume(Task3Handle);
			vTaskSuspend(Task1Handle);
			vTaskSuspend(Task2Handle);
			vTaskSuspend(EmerTaskHandle);
			break;
		}
	}
}
/* USER CODE END 0 */

/**
 * @brief  The application entry point.
 * @retval int
 */
int main(void) {

	/* USER CODE BEGIN 1 */

	/* USER CODE END 1 */

	/* MCU Configuration--------------------------------------------------------*/

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();

	/* USER CODE BEGIN Init */

	/* USER CODE END Init */

	/* Configure the system clock */
	SystemClock_Config();

	/* USER CODE BEGIN SysInit */

	/* USER CODE END SysInit */

	/* Initialize all configured peripherals */
	MX_GPIO_Init();
	MX_USART1_UART_Init();
	/* USER CODE BEGIN 2 */
	//vTaskSuspend(Task1Handle);
	EventGroupHandle = xEventGroupCreate();
	mutexHandle = xSemaphoreCreateMutex();
	TimerHandle = xTimerCreate("time_data", pdMS_TO_TICKS(50), pdFALSE, 0, TimerTask);

	xTaskCreate(controller_Task, "task_c", 128, NULL, 2, &ControlHandle);
	xTaskCreate(Task1, "task1", 128, NULL, 1, &Task1Handle);
	xTaskCreate(Task2, "task2", 128, NULL, 1, &Task2Handle);
	xTaskCreate(Task3, "task3", 128, NULL, 1, &Task3Handle);
	xTaskCreate(Emer_Task, "Emer_task", 128, NULL, 2, &EmerTaskHandle);
	xTaskCreate(UART_Task, "UART", 256, NULL, 1, &UARTHandle);

	vTaskSuspend(EmerTaskHandle);
	vTaskSuspend(Task1Handle);
	vTaskSuspend(Task2Handle);
	vTaskSuspend(Task3Handle);


	//xTimerStart(TimerHandle,0);
	vTaskStartScheduler();
	/* USER CODE END 2 */

	/* Create the mutex(es) */
	/* definition and creation of myMutex01 */
//  osMutexDef(myMutex01);
//  myMutex01Handle = osMutexCreate(osMutex(myMutex01));
	/* USER CODE BEGIN RTOS_MUTEX */
//  /* add mutexes, ... */
	/* USER CODE END RTOS_MUTEX */

	/* USER CODE BEGIN RTOS_SEMAPHORES */
//  /* add semaphores, ... */
	/* USER CODE END RTOS_SEMAPHORES */

	/* Create the timer(s) */
	/* definition and creation of myTimer01 */
//  osTimerDef(myTimer01, Callback01);
//  myTimer01Handle = osTimerCreate(osTimer(myTimer01), osTimerPeriodic, NULL);
	/* USER CODE BEGIN RTOS_TIMERS */
//  /* start timers, add new ones, ... */
	/* USER CODE END RTOS_TIMERS */

	/* USER CODE BEGIN RTOS_QUEUES */
//  /* add queues, ... */
	/* USER CODE END RTOS_QUEUES */

	/* Create the thread(s) */
	/* definition and creation of defaultTask */
//  osThreadDef(defaultTask, StartDefaultTask, osPriorityNormal, 0, 128);
//  defaultTaskHandle = osThreadCreate(osThread(defaultTask), NULL);
	/* USER CODE BEGIN RTOS_THREADS */
//  /* add threads, ... */
	/* USER CODE END RTOS_THREADS */

	/* Start scheduler */
	//osKernelStart();
	/* We should never get here as control is now taken by the scheduler */

	/* Infinite loop */
	/* USER CODE BEGIN WHILE */
	while (1) {
		/* USER CODE END WHILE */

		/* USER CODE BEGIN 3 */
	}
	/* USER CODE END 3 */
}

/**
 * @brief System Clock Configuration
 * @retval None
 */
void SystemClock_Config(void) {
	RCC_OscInitTypeDef RCC_OscInitStruct = { 0 };
	RCC_ClkInitTypeDef RCC_ClkInitStruct = { 0 };

	/** Configure the main internal regulator output voltage
	 */
	__HAL_RCC_PWR_CLK_ENABLE();
	__HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

	/** Initializes the RCC Oscillators according to the specified parameters
	 * in the RCC_OscInitTypeDef structure.
	 */
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
	RCC_OscInitStruct.HSIState = RCC_HSI_ON;
	RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
		Error_Handler();
	}

	/** Initializes the CPU, AHB and APB buses clocks
	 */
	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
			| RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
	RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK) {
		Error_Handler();
	}
}

/**
 * @brief USART1 Initialization Function
 * @param None
 * @retval None
 */
static void MX_USART1_UART_Init(void) {

	/* USER CODE BEGIN USART1_Init 0 */

	/* USER CODE END USART1_Init 0 */

	/* USER CODE BEGIN USART1_Init 1 */

	/* USER CODE END USART1_Init 1 */
	huart1.Instance = USART1;
	huart1.Init.BaudRate = 115200;
	huart1.Init.WordLength = UART_WORDLENGTH_8B;
	huart1.Init.StopBits = UART_STOPBITS_1;
	huart1.Init.Parity = UART_PARITY_NONE;
	huart1.Init.Mode = UART_MODE_TX_RX;
	huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart1.Init.OverSampling = UART_OVERSAMPLING_16;
	if (HAL_UART_Init(&huart1) != HAL_OK) {
		Error_Handler();
	}
	/* USER CODE BEGIN USART1_Init 2 */

	/* USER CODE END USART1_Init 2 */

}

/**
 * @brief GPIO Initialization Function
 * @param None
 * @retval None
 */
static void MX_GPIO_Init(void) {
	GPIO_InitTypeDef GPIO_InitStruct = { 0 };
	/* USER CODE BEGIN MX_GPIO_Init_1 */

	/* USER CODE END MX_GPIO_Init_1 */

	/* GPIO Ports Clock Enable */
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOG_CLK_ENABLE();

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOG,
			GPIO_PIN_10 | GPIO_PIN_11 | GPIO_PIN_12 | GPIO_PIN_13 | GPIO_PIN_14,
			GPIO_PIN_RESET);

	/*Configure GPIO pins : PA0 PA1 PA2 PA3 */
	GPIO_InitStruct.Pin = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3;
	GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
	GPIO_InitStruct.Pull = GPIO_PULLDOWN;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
	;
	/*Configure GPIO pins : PG10 PG11 PG12 PG13
	 PG14 */
	GPIO_InitStruct.Pin = GPIO_PIN_10 | GPIO_PIN_11 | GPIO_PIN_12 | GPIO_PIN_13
			| GPIO_PIN_14;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

	/* EXTI interrupt init*/
	HAL_NVIC_SetPriority(EXTI0_IRQn, 5, 0);
	HAL_NVIC_EnableIRQ(EXTI0_IRQn);

	HAL_NVIC_SetPriority(EXTI1_IRQn, 5, 0);
	HAL_NVIC_EnableIRQ(EXTI1_IRQn);

	HAL_NVIC_SetPriority(EXTI2_IRQn, 5, 0);
	HAL_NVIC_EnableIRQ(EXTI2_IRQn);

	HAL_NVIC_SetPriority(EXTI3_IRQn, 5, 0);
	HAL_NVIC_EnableIRQ(EXTI3_IRQn);

	/* USER CODE BEGIN MX_GPIO_Init_2 */

	/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void Task1(void *args) {
	for (;;) {
		Toggle_LED(Task1_sw);
		vTaskDelay(pdMS_TO_TICKS(500));
	}
}
void Task2(void *args) {
	for (;;) {
		Toggle_LED(Task2_sw);
		vTaskDelay(pdMS_TO_TICKS(1000));
	}
}
void Task3(void *args) {
	for (;;) {
		Toggle_LED(Task3_sw);
		vTaskDelay(pdMS_TO_TICKS(1500));
	}
}
void Emer_Task(void *args) {
	for (;;) {
		Toggle_LED(Emer_sw);
		vTaskDelay(pdMS_TO_TICKS(250));
	}
}
void TimerTask(void*args){
	//BaseType_t xHigherPriorityTaskWoken = pdFALSE;
	if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0)==1)
	{
		xEventGroupSetBits(EventGroupHandle, EMER_TASK_BIT);
	}
	else if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_1)==1)
	{
		xEventGroupSetBits(EventGroupHandle, TASK1_BIT);
	}
	else if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_2)==1)
	{
		xEventGroupSetBits(EventGroupHandle, TASK2_BIT);
	}
	else if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_3)==1)
	{
		xEventGroupSetBits(EventGroupHandle, TASK3_BIT);
	}
	//portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}

void UART_Task(void *args) {
	char STATUS[200];
	for (;;) {
		//STATUS = xEventGroupWaitBits(EventGroupHandle,EMER_TASK_BIT | TASK1_BIT | TASK2_BIT | TASK3_BIT, pdTRUE,pdFALSE, portMAX_DELAY);
//		if (STATUS == EMER_TASK_BIT) {
//			HAL_UART_Transmit(&huart1, "Emergency task running\r\n", 25,
//			portMAX_DELAY);
//		} else if (STATUS == TASK1_BIT) {
//			HAL_UART_Transmit(&huart1, "Task1 running\r\n", 16, portMAX_DELAY);
//		} else if (STATUS == TASK2_BIT) {
//			HAL_UART_Transmit(&huart1, "Task2 running\r\n", 16, portMAX_DELAY);
//		} else if (STATUS == TASK3_BIT) {
//			HAL_UART_Transmit(&huart1, "Task3 running\r\n", 16, portMAX_DELAY);
//		}
		printf("Task_Name    State    Prio    Stack   NO\r\n");
		printf("---------------------------------------\r\n");
		vTaskList(STATUS);
		HAL_UART_Transmit(&huart1,(uint8_t*) STATUS,strlen(STATUS),portMAX_DELAY);
		vTaskDelay(pdMS_TO_TICKS(2000));
		printf("\r\n");
	}
}
/* USER CODE END 4 */

/* USER CODE BEGIN Header_StartDefaultTask */
/**
 * @brief  Function implementing the defaultTask thread.
 * @param  argument: Not used
 * @retval None
 */
/* USER CODE END Header_StartDefaultTask */
//void StartDefaultTask(void const * argument)
//{
//  /* USER CODE BEGIN 5 */
////  /* Infinite loop */
////  for(;;)
////  {
////    osDelay(1);
////  }
//  /* USER CODE END 5 */
//}
//
///* Callback01 function */
//void Callback01(void const * argument)
//{
//  /* USER CODE BEGIN Callback01 */
////\
//  /* USER CODE END Callback01 */
//}
/**
 * @brief  Period elapsed callback in non blocking mode
 * @note   This function is called  when TIM1 interrupt took place, inside
 * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
 * a global variable "uwTick" used as application time base.
 * @param  htim : TIM handle
 * @retval None
 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) {
	/* USER CODE BEGIN Callback 0 */

	/* USER CODE END Callback 0 */
	if (htim->Instance == TIM1) {
		HAL_IncTick();
	}
	/* USER CODE BEGIN Callback 1 */

	/* USER CODE END Callback 1 */
}

/**
 * @brief  This function is executed in case of error occurrence.
 * @retval None
 */
void Error_Handler(void) {
	/* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1) {
	}
	/* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
